package my_pack;

public interface Int_my {
	public double calculate_salary(double salary,double TA,int DA,double HR);
}
